import 'package:flutter/material.dart';

// Colors
const mPrimaryTextColor = Color(0xFF0C8863);
const mTitleTextColor = Color(0xFF000000);
const mBackgroundColor = Color(0xFFFFFFFF);
const mSecondBackgroundColor = Color(0xFFCCCCCC);
const mButtonColor = Color(0xFF5063FF);
const mYellowColor = Color(0xFF0C8863);