import 'package:flutter/material.dart';
import 'package:nascp/utils/choose_time.dart';
import 'package:nascp/utils/constant.dart';

import 'package:nascp/utils/choose_model.dart';


class DosageDisplay extends StatelessWidget {

  final String drug;
  final String dosage;
  final String weightBand;

  const DosageDisplay({
    Key key, this.drug, this.dosage, this.weightBand
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          drug,
          style: TextStyle(
            color: mTitleTextColor,
            fontSize: 18,
            fontWeight: FontWeight.w600,
            fontFamily: "Truedo"
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Text(drug)
      ],
    );
  }


}