
class GridItem {
  String title;
  String icon;
  String subtitle;
  String touchPoint;
  GridItem({this.title, this.icon, this.subtitle, this.touchPoint});
}