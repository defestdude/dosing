import 'package:flutter/material.dart';
import 'package:nascp/utils/constant.dart';

class UserInfo extends StatelessWidget {
  const UserInfo({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: <Widget>[
          Image.asset(
            'assets/images/hiv.png',
            width: 100,
            height: 100,
          ),
 
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                width: 250,
                child: Text(
                  'ABC/3TC',
                  style: TextStyle(
                    color: mTitleTextColor,
                    fontSize: 38,
                    fontWeight: FontWeight.bold,
                    fontFamily: "Truedo"
                  ),
                  maxLines: 3,
                ),
              ),
              Text('120 / 60 mg',style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),)
            ],
          )
        ],
      ),
    );
  }
}
