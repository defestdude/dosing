class ChooseModel {
  String time;
  bool check;

  ChooseModel(this.time, {this.check = false});
}
