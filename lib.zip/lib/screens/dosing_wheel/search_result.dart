import 'package:download_assets/download_assets.dart';
import 'package:flutter/material.dart';
import 'package:nascp/models/peds_dosage_model.dart';
import 'package:nascp/screens/drawer_screen.dart';
import 'package:nascp/utils/choose_date.dart';
import 'package:nascp/utils/choose_model.dart';
import 'package:nascp/utils/choose_time_group.dart';
import 'package:nascp/utils/dosage_display.dart';
import 'package:nascp/utils/my_appbar.dart';
import 'package:nascp/utils/my_header.dart';
import 'package:nascp/utils/user_info.dart';
import 'package:nascp/utils/constant.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as Path; //used to join paths


class SearchResult extends StatefulWidget {
  // In the constructor, require a Todo.
  const SearchResult({Key key, this.weight, this.weightText, this.regimenid}) : super(key: key);

  // Declare a field that holds the Todo.
  final int weight;
  final int regimenid;
  final String weightText;

  @override
  _SearchResultState createState() => _SearchResultState();
}




class _SearchResultState extends State<SearchResult> {
  var db;
  List<PedsDosageModel> dosageResults;

    @override
  void initState() {
    query();
    super.initState();
  }

  void query() async {
    // raw query
    final path = Path.join(DownloadAssetsController.assetsDir, "dosing.db");
    db = await openDatabase(path);
    this.dosageResults = await fetchDosageResults();
    //print(widget.regimenid);
    setState(() {});
  }

Future<List<PedsDosageModel>> fetchDosageResults() async {
    //returns the memos as a list (array)

    //final db = await init();
    final maps = await db.rawQuery(
        'select drugs.drug, dosage.dose, weight.weight_band from dosage join weight on dosage.weight = weight.id join drugs on dosage.drugs = drugs.id join drugs_regimen on drugs.id = drugs_regimen.drugs where drugs_regimen.regimen = ? and dosage.weight = ?',
        [widget.regimenid, widget.weight]); //query all the rows in a table as an array of maps

    return List.generate(maps.length, (i) {
      //create a list of memos
      return PedsDosageModel(drug: maps[i]['drug'], dose: maps[i]['dose'], weightBand: maps[i]['weightBand']);
    });
  }


  final _scaffoldKey = GlobalKey<ScaffoldState>(); 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,    
      drawer: DrawerScreen(),
      body: Column(
        children: <Widget>[
          MyHeader(
            height: 258,
            imageUrl: 'assets/images/hiv.png',
            child: Column(
              children: <Widget>[
                SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
              alignment: Alignment.topLeft,
              child: IconButton(
                icon: Icon(Icons.menu),
                onPressed: () {
                   _scaffoldKey.currentState.openDrawer();
                }),
            ),
      ),
                ),
                SizedBox(
                  height: 16,
                ),
                UserInfo(),
              ],
            ),
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [mBackgroundColor, mSecondBackgroundColor],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  ChooseSlot(),
                  SizedBox(
                    height: 32,
                  ),
                  dosageResults == null
                      ? Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        child: Text("None"),
                      )
                      :Column(
                  children:  dosageResults.map<Widget>((PedsDosageModel dosage) {
                          return new DosageDisplay(
                            drug: dosage.drug,
                    dosage:dosage.dose,
                          );
                        }).toList(),
                ),
                  ChooseTimeGroup(
                    title: 'Side Effects',
                    story:"Side effects may vary across children with asthma",
                  ),
                  SizedBox(
                    height: 32,
                  ),
                  ChooseTimeGroup(
                    title: 'Additional Information',
                    story:"Drugs must not be administered with Antihisthamines",
                  ),
                  SizedBox(
                    height: 32,
                  ),
                  ChooseTimeGroup(
                    title: 'Instructions for Use',
                    story:"ABC/3TC comes as dispersible tablets and is indicated for us in combination with other antiretroviral agents with or without food. Children who can reliably swallow tablets should swallow the tablet whole.",
                  ),
       
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ChooseSlot extends StatelessWidget {
  const ChooseSlot({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          'Dosage',
          style: TextStyle(
            color: mTitleTextColor,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(
          height: 18,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            ChooseDate(
              week: '3 - 5.9 kg',
              date: '1',
            ),
            ChooseDate(
              week: '6 - 9.9kg',
              date: '1.5',
              check: true,
            ),
            ChooseDate(
              week: '10 - 13.9kg',
              date: '2',
            ),
            ChooseDate(
              week: '14 - 19.9kg',
              date: '2.5',
            ),
           
          ],
        )
      ],
    );
  }
}
