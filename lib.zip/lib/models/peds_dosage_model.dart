class PedsDosageModel{
  final String drug;
  final String dose;
  final String weightBand;


  PedsDosageModel({this.drug,this.dose, this.weightBand});

  Map<String,dynamic> toMap(){ // used when inserting data to the database
    return <String,dynamic>{
      "drug" : drug,
      "dose" : dose, 
      "weight_band" : weightBand
    };
  }
}